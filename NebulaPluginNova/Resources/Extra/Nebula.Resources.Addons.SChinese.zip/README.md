> 声明：本项目为BepInEx插件Nebula on the Ship的Addon附加包，非隶属于游戏Among Us及Innersloth LLC.
# SChinese Language Pack
本项目提供了Among Us的BepInEx插件Nebula on the Ship的简体中文汉化

该项目的翻译主要基于Krolf主编以及Khcell的大部分修改，主要分为三个部分：
 - 1.基础翻译部分
 - 2.成就及称号翻译部分
 - 3.自定义颜色翻译部分
